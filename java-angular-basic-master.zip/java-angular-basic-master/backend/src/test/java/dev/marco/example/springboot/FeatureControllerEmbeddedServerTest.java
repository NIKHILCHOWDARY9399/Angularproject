package dev.marco.example.springboot;

/**
 *  * We didn't implement the version with the RestTemplate because spring doesn't like GET requests with body.
 *  * You can find more details about this issue in this post: https://marco.dev/spring-boot-test-get-body
 */
public class FeatureControllerEmbeddedServerTest {
}
